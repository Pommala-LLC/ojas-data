# 08_raw_sql_rejected_policy_built — Raw SQL rejected in Policy-Built Mode

## Scenario

An operator (actor-kind=operator) submits a raw SQL string via the `sql-review-request` path with `mode=review-only`. The system is configured in Policy-Built Mode, which structurally rejects raw SQL even for review. Decision: denied. Sanitized feedback explains the rejection.

This scenario codifies the **resolved Finding 5** from the focused review: raw SQL rejection in Policy-Built Mode is intended behavior, not a bug.

## Files

| File | Validates against | Notes |
|---|---|---|
| `request.json` | `bundle/sql-review-request` | Uses the separate SQL review path (catalog §2.12); requires reviewer-principal-id and elevated-policy-ref |
| `response.json` | `bundle/sql-review-response` | Decision denied; audit envelope-wrapped |
| `audit.json` | `evidence-store/evidence-record` | data-operation-audit, effective-decision=deny-structural |
| `sanitized_feedback.json` | `bundle/sanitized-feedback` | `category: raw-diagnostic-blocked` |

## V0.3.2 patterns demonstrated

- Separate `sql-review-request` path — raw SQL is NEVER on `data-execute-request`
- Negative fixture `_negative/request_with_sql_field` proves the schema rejects `sql` on data-execute-request
- Operator actor-kind, not agent — the SQL review path is human-authored
- `deny-structural` effective decision for shape-level rejection
