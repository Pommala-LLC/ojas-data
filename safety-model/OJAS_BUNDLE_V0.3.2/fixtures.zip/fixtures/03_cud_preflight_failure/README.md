# 03_cud_preflight_failure — Agent update fails preflight check

## Scenario

Agent (actor-kind=agent) requests an update. Tier D digest requirement triggers (agent + update operation), digests are present. Mutation preflight runs; `row-estimate` check fails (bulk limit exceeded); `effective-decision=deny-by-precondition`.

## Files

| File | Validates against | Notes |
|---|---|---|
| `request.json` | `bundle/data-execute-request` | Agent actor; both Tier D digests present |
| `response.json` | `bundle/data-execute-response` | `preflight` carries structured `mutation-preflight-result` per v0.3.1 D-F2 |
| `audit.json` | `evidence-store/evidence-record` | data-operation-audit, stage=preflight-failure |
| `preflight_orchestration.json` | `evidence-store/evidence-record` | mutation-preflight-orchestration record, references preflight result by digest |

## V0.3.2 patterns demonstrated

- Tier D digest enforcement (D-F4): agent + mutate op requires both digests at request time
- `mutation-preflight-result` carried structurally in response, by digest in orchestration record (D-F2)
- Closed preflight check enum (v0.3 delta 4): scope-verification, tenant-isolation present
- Orchestration record `safety-critical-checks-present: true` + decision=deny-by-precondition validates §3.8 conditional
