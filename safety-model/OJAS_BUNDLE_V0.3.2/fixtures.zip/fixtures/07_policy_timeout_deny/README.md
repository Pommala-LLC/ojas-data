# 07_policy_timeout_deny — Policy authority timeout triggers fail-closed

## Scenario

Agent requests a destructive delete. Gate event emitted to external policy authority. Authority does not respond within the D-1 500ms ceiling. Timeout fires; effective decision is `deny-by-timeout` (forensically distinct from `deny-by-policy` per D-2). Audit records the policy-response-timeout per §5.2 conditional rule.

## Files

| File | Validates against | Notes |
|---|---|---|
| `gate_event.json` | `runtime-data/pre-execution-gate-event` | Wire-protocol message |
| `gate_response_timeout.json` | `runtime-data/policy-response-timeout` | Wire-protocol timeout marker; `effective-decision: deny-by-timeout` (const) |
| `response.json` | `bundle/data-execute-response` | Carries deny-by-timeout decision and sanitized feedback |
| `audit.json` | `evidence-store/evidence-record` | data-operation-audit stage=denial, `policy-response-timeout-recorded: true` |

## V0.3.2 patterns demonstrated

- D-1 latency budget (500ms ceiling, 200ms target)
- D-2 forensic distinction: `deny-by-timeout` vs `deny-by-policy`
- §5.2 conditional rule: `policy-response-timeout-recorded` required when `effective-decision=deny-by-timeout`
- Fail-closed semantics — timeout means deny, not allow
