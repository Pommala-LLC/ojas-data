# 04_destructive_delete_preexec_required — Destructive delete through pre-execution gate

## Scenario

Agent deletes a student record. Action class is `destructive` → pre-execution audit binding required (D-1 sync gate path). Gate event sent to external policy authority; authority approves; delete executes.

## Files

| File | Validates against | Notes |
|---|---|---|
| `request.json` | `bundle/data-execute-request` | Agent + Tier D digests + `pre-execution-audit-ref` populated |
| `response.json` | `bundle/data-execute-response` | Decision allowed; preflight passed |
| `audit.json` | `evidence-store/evidence-record` | data-operation-audit, stage=post-execution |
| `gate_event.json` | `runtime-data/pre-execution-gate-event` | Wire-protocol message (NOT envelope-wrapped) |
| `gate_response.json` | `runtime-data/pre-execution-gate-response` | Wire-protocol response |
| `pre_execution_audit_binding.json` | `evidence-store/evidence-record` | Envelope-wrapped binding record |

## V0.3.2 patterns demonstrated

- Pre-execution gate path (D-1 sync, 500ms ceiling)
- Wire-protocol messages (gate event/response) NOT envelope-wrapped — they are live exchanges, not stored audit
- Binding record IS envelope-wrapped (D-F3) and references the bound policy decision + query digests
- `pre-execution-audit-ref` on request points back to binding record
