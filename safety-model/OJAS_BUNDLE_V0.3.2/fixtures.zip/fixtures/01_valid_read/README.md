# 01_valid_read — Baseline LLM-path read

## Scenario

A human user (actor-kind=human) requests a read of `student_profile` via the LLM-extracted intent path. Policy resolves to `allowed`; query executes; field-level audit emitted.

## Files

| File | Validates against | Notes |
|---|---|---|
| `request.json` | `bundle/data-execute-request` | Human actor, no Tier D digest requirement |
| `response.json` | `bundle/data-execute-response` | Decision allowed; audit envelope-wrapped per v0.3.1 D-F3 |
| `audit.json` | `evidence-store/evidence-record` | Standalone field-level audit envelope (record-type=field-level-audit, emitter=ojas-runtime-data) |

## V0.3.2 patterns demonstrated

- Envelope-wrapped audit (D-F3)
- Opaque audit-id format (D-F1, regex `^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$`)
- Catalog-silent placeholders: `scope-predicates: [{}]`, `resolved-intent.fields/scope/filters` as empty objects
- Tier D digest NOT required (actor-kind=human, not agent)

