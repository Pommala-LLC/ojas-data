# Negative fixtures

Each subfolder here contains a fixture the schema MUST reject. The validator checks both that the schema rejects it AND that the produced errors contain the expected error substrings.

## Layout per fixture

```
<fixture_name>/
    instance.json        — the malformed instance
    target.txt           — schema-label/defs-name (e.g., bundle/data-execute-request)
    expected_error.txt   — error substrings the schema MUST produce (one per line; # comments allowed)
```

## Included negative fixtures (V0.3.2)

| Folder | Locks |
|---|---|
| `request_with_sql_field` | Invariant I-6: data-execute-request rejects `sql` field; LLM authors intent, not executables |
| `audit_payload_without_evidence_envelope` | v0.3.1 D-F3: bare audit payloads are not protocol messages; envelope is canonical |
| `wrong_emitter_for_record_type` | Catalog §5.3/§9.3 + v0.3.1 §3.6 correction: emitter must match record-type discriminator |
| `input_with_both_extracted_intent_and_input` | v0.3.1 D-C1: XOR rule rejects requests with both paths |
| `input_with_neither_extracted_intent_nor_input` | v0.3.1 D-C1: XOR rule rejects requests with neither path |

## Parked negative fixtures

These were considered but not added in V0.3.2. See VALIDATION_REPORT.md §3 for full reasoning.

| Folder name (would be) | Reason parked |
|---|---|
| `unsafe_open_input_extra_fields` | Schema deliberately allows extra fields on §2.13 input stubs per catalog freeze-safety; negative test would currently pass schema validation. Becomes valid once full per-operation input shapes are defined. |
| `preflight_missing_scope_verification` | Catalog §2.8 profile rule is runtime-enforced, not schema-enforced. Becomes valid if schema is extended with `contains` constraint on `mutation-preflight-result.checks`. |
| `preflight_missing_tenant_isolation` | Same reason. |
