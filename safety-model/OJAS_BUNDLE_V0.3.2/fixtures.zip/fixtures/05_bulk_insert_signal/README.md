# 05_bulk_insert_signal — Bulk-context observation triggered

## Scenario

Agent performs an insert. The insert succeeds. Separately, the bulk-context detector emits a signal because the agent has performed 142 inserts on `student_profile` within the 60-second window (D-5 threshold: default 100).

## Files

| File | Validates against | Notes |
|---|---|---|
| `request.json` | `bundle/data-execute-request` | Agent + Tier D digests |
| `response.json` | `bundle/data-execute-response` | Decision allowed; preflight passed |
| `audit.json` | `evidence-store/evidence-record` | data-operation-audit, stage=post-execution |
| `bulk_context_observed.json` | `evidence-store/bulk-context-observed` | Standalone signal payload (typed, not envelope-wrapped — per §6.1 it is a typed signal) |

## V0.3.2 patterns demonstrated

- Bulk-context signal (D-5): 60-second window, per-(actor, entity), default threshold 100
- Signal validates against its own `$defs` entry, not via evidence-record envelope (catalog §6.1 typed signal)
- Tier D digest enforcement for agent insert (mutate operation)
