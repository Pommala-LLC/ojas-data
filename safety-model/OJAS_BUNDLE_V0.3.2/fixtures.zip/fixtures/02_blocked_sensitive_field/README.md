# 02_blocked_sensitive_field — Sensitive field blocked by policy

## Scenario

Human user reads `student_profile` requesting `name` and `ssn`. Policy returns `decision=masked`; `ssn` is blocked; `name` is returned. Sanitized feedback informs the user.

## Files

| File | Validates against | Notes |
|---|---|---|
| `request.json` | `bundle/data-execute-request` | Human actor |
| `response.json` | `bundle/data-execute-response` | Decision masked; `blocked-fields: [{}]` uses empty-object placeholder |
| `audit.json` | `evidence-store/evidence-record` | Field-level audit with `fields-returned` and `fields-blocked` populated |
| `sanitized_feedback.json` | `bundle/sanitized-feedback` | Standalone sanitized-feedback for `governance-sensitive-blocked` |

## V0.3.2 patterns demonstrated

- `decision=masked` with `blocked-fields` populated (S11 catalog-silent placeholder)
- Sanitized feedback uses closed `summary-template-id`, no free-text (v0.3 delta 6)
- `fields-returned` required for post-execution read per catalog §3.6
