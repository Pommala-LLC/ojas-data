# 06_create_after_destroy_signal — Create-after-destroy pattern detected

## Scenario

Agent deletes student record `12345`, then ~5 minutes later inserts a new record for the same scope dimension. Within the D-6 30-minute window, this matches the create-after-destroy pattern. Detector emits the observation signal with `exact-match` confidence class.

## Files

| File | Validates against | Notes |
|---|---|---|
| `destroy_audit.json` | `evidence-store/evidence-record` | The earlier destroy audit (envelope-wrapped) |
| `create_audit.json` | `evidence-store/evidence-record` | The later create audit (envelope-wrapped) |
| `create_after_destroy_observed.json` | `evidence-store/create-after-destroy-observed` | Standalone signal payload |

## V0.3.2 patterns demonstrated

- Create-after-destroy detection (D-6): 30-minute window, (tenant, entity, actor, scope-dimension) tuple
- `pattern-confidence-class: exact-match` — all three confidence classes preserved per v0.3.2 O-3
- Both audits cross-referenced from the signal via `destroy-audit-ref` / `create-audit-ref`
- `window-seconds: 1800` const enforced by schema
